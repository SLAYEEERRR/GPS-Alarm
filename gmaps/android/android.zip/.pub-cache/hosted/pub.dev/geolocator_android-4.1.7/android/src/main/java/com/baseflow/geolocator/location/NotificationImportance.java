package com.baseflow.geolocator.location;

public enum NotificationImportance {
    Default,
    High,
    Max,
}
