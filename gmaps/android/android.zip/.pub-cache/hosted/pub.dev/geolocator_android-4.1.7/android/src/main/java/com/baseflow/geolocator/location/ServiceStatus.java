package com.baseflow.geolocator.location;

public enum ServiceStatus {
    disabled,
    enabled
}
